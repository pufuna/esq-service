@echo off
cd /d "%~dp0"
if not exist "ESQ ME800 Service.exe" (echo ERROR: put this file into the ESQ_ME800_Service folder next to "ESQ ME800 Service.exe". & pause & exit /b 1)
echo Creating shortcut "ESQ Service" on the desktop and in the Start menu...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=(Resolve-Path '%~dp0.').Path; $e=Join-Path $d 'ESQ ME800 Service.exe'; $w=New-Object -ComObject WScript.Shell; foreach($f in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))){ $l=$w.CreateShortcut((Join-Path $f 'ESQ Service.lnk')); $l.TargetPath=$e; $l.WorkingDirectory=$d; $l.IconLocation=$e+',0'; $l.Description='ESQ Service - ESQ F ME800 / ESQ F HVS / ESQ-500/600 / ESQ-770 / ESQ F790'; $l.Save() }"
if errorlevel 1 (echo ERROR: shortcut was not created. & pause & exit /b 1)
echo Done. Do not move or delete this folder - the shortcut points to it.
pause
